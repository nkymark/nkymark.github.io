%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%             Script for Exercise 2 of IEEE CCTA Workshop 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% This file defines the structural model of a single turbo petrol engine.
%%
%% Author:   Mark Kok Yew Ng (mark.ng@ulster.ac.uk)
%%
%% Version 1.0: 05-02-2015
%% Version 2.0: 19-08-2024
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% Unknown variables
% 59 variables, 13 are states, 13 are d terms, 6 are inputs
Xvar = { 'dpaf'     'dTaf'      'dpc'       'dTc'       'dpic'      'dTic'  'dpim'  'dTim'  'dpem'  'dTem' ...
    'dpt'      'dTt'       'domegat' ...
    'etac'     'etat'      'lambdac'   'omegat'    'omegae'    'paf'   'pamb'  'pc'    'pic'   'xwg'  ...
    'pim'      'pem'       'pt'        'Wth'       'PIc'       'PIt'   'Taf'   'Tic'   'Tamb'  'Tc'   ...
    'Tc1'      'Teo'       'Tem'       'Tim'       'Tqc'       'Tqt'   'Tt'    'Tth'   'Tti'   'Tto'  ...
    'Tflow'    'Tturbo'    'Taf1'     	'Waf'       'Wc'        'Wei'   'Wf'    'Weo'   'Wic'   'Wt'   ...
    'Wes'      'Wesfinal'  'Wwg'       'xth'       'Twg1'      'Tt1' };

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Known variables
% 7 output sensors and 6 input sensors
Zvar = { 'yTc'      'ypc'   'yTic'  'ypic'      'yTim'  'ypim'  'yWaf' ...
    'upamb'    'uTamb' 'uxth' 'ulambdac'  'uxwg'  'uomegae' };

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Faults
% 11 faults (6 variable faults, 1 aatuator fault, and 4 sensor faults)
Fvar = { 'fpaf'     'fomegat'   'fWaf'   'fWc'    'fWic'  'fWth' ...
    'fxth'     'fypic'     'fypim'  'fyTic'  'fyWaf' };

%% Define structure
% Each line represents a model relation and lists all involved variables.

rels = { ...
    { 'dTaf'     'Wc'        'Waf'       'Tamb'      'paf'   'Taf1'  },...   %
    { 'dpaf'     'Taf'       'Wc'        'Waf'                       },...   %
    { 'dTc'      'Wc'        'Wic'       'Tc1'       'pc'            },...   %
    { 'dpc'      'Tc'        'Wc'        'Wic'                       },...   %
    { 'dTic'     'Tflow'     'Wic'       'Wth'       'Tth'   'pic'   },...   %
    { 'dpic'     'Tic'       'Wic'       'Wth'                       },...   %
    { 'dTim'     'Wth'       'Wei'       'Tth'       'pim'           },...   %
    { 'dpim'     'Tim'       'Wth'       'Wei'                       },...   %
    { 'dTem'     'Weo'       'Wes'       'Tti'       'pem'           },...   %
    { 'dpem'     'Tem'       'Wes'       'Weo'                       },...   %
    { 'dTt'      'Wes'       'Wesfinal'  'Tturbo'    'Tt1'   'pt'    },...   %
    { 'dpt'      'Tt'        'Wes'       'Wesfinal'                  },...   %
    { 'domegat'  'Tqc'       'Tqt'       'fomegat'                   },...   %
    { 'Taf1'     'pamb'      'Tamb'      'paf'       'Taf'           },...   %
    { 'Waf'      'Taf1'      'paf'       'pamb'      'fWaf'  'fpaf'  },...   %
    { 'PIc'      'pc'        'paf'                                   },...   %
    { 'Wc'       'omegat'    'paf'       'Taf'       'pc'    'fWc'   },...   %
    { 'etac'     'omegat'    'Wc'        'paf'       'Taf'           },...   %
    { 'Tc1'      'Taf'       'PIc'       'etac'                      },...   %
    { 'Tqc'      'Tc1'       'Taf'       'omegat'    'Wc'            },...   %
    { 'Tflow'    'Tc'        'Tamb'      'Tic'       'pc'    'pic'   },...   %
    { 'Wic'      'pc'        'pic'       'Tc'        'Tic'   'fWic'  },...   %
    { 'Tth'      'Tic'       'pic'       'pim'       'Tim'           },...   %
    { 'Wth'      'Tth'       'pim'       'pic'       'xth'   'fWth'  },...   %
    { 'Wei'      'pem'       'omegae'    'pim'       'Tim'           },...   %
    { 'Wf'       'Wei'       'lambdac'                               },...   %
    { 'Weo'      'Wei'       'Wf'                                    },...   %
    { 'Teo'      'Weo'                                               },...   %
    { 'Tti'      'Teo'       'Weo'       'Tamb'                      },...   %
    { 'Twg1'     'pem'       'Tem'       'pt'        'Tt'            },...   %
    { 'Wwg'      'Tem'       'pem'       'xwg'       'pt'    'Tt'    },...   %
    { 'PIt'      'pt'        'pem'                                   },...   %
    { 'etat'     'PIt'       'omegat'    'Tem'                       },...   %
    { 'Tto'      'Tem'       'PIt'       'etat'                      },....  %
    { 'Wt'       'pem'       'Tem'       'PIt'                       },...   %
    { 'Tqt'      'Wt'        'omegat'    'Tem'       'Tto'           },...   %
    { 'Wes'      'Wt'        'Wwg'                                   },...   %
    { 'Tturbo'   'Wt'        'Wwg'       'Tto'       'Twg1'          },...   %
    { 'Tt1'      'pamb'      'Tamb'      'pt'        'Tt'            },...   %
    { 'Wesfinal' 'Tt1'       'pamb'      'pt'                        },...   %
    ...%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    { 'paf'                                                          },...   % Nothing interesting here.
    { 'Taf'                                                          },...   % Just derivatives.
    { 'pc'                                                           },...
    { 'Tc'                                                           },...
    { 'pic'                                                          },...
    { 'Tic'                                                          },...
    { 'pim'                                                          },...
    { 'Tim'                                                          },...
    { 'pem'                                                          },...
    { 'Tem'                                                          },...
    { 'pt'                                                           },...
    { 'Tt'                                                           },...
    { 'omegat'                                                       },...
    ...%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    {                                                                },...   % The input sensors
    ...%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    {                                                                },...   % The output sensors
    };

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compute the incidence matrices

X = symbdef( rels, Xvar ) > 0;
F = symbdef( rels, Fvar ) > 0;
Z = symbdef( rels, Zvar ) > 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Build SM object

SM      = CreateSM( X, F, Z, {}, Xvar, Fvar, Zvar );
SM.name = 'Structural Model of A Single Turbo Petrol Engine';

M       = X(1:46,:);
sizeM   = size( M );
sprankM = sprank( M );
Ms      = X(47:53,:);

dm      = GetDMParts( [M; Ms(1,:)] );
any( SM.F(dm.Mp.row,:) );
SM.f(any( SM.F(dm.Mp.row,:) ) == 1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plot Model

scrsz = get( 0, 'ScreenSize' );
figure( 'Position', [1 scrsz(4) / 10 scrsz(3) / 1.5 scrsz(4) / 1.5] );
PlotSM( SM );
grid on;
set( gca, 'FontName', 'Courier', 'Title', text( 'String', SM.name, 'FontSize', 14, ...
    'FontName', 'Courier' ), 'FontWeight', 'Bold', 'GridLineStyle', ':' );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Perform isolability analysis

figure( 'Position', [scrsz(3) / 2 scrsz(4) / 10 scrsz(3) / 1.5 scrsz(4) / 1.5] );
[im, ndf, df]   = IsolabilityAnalysisSM( SM );
[p, q, r, s]    = dmperm( im );
spy( im( p, q ), 40 );

grid on;
Xt  = 1:length( SM.f );
t   = text( Xt, (length( SM.f ) + 1) * ones( 1, length( SM.f )), SM.f(p) );
set( t, 'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', 'Rotation', ...
    45, 'FontSize', 13, 'FontName', 'Courier', 'FontWeight', 'Bold' );
xlabel( ' ' );
set( gca, 'GridLineStyle', ':', 'YTickLabel', SM.f(p), 'YTick', 1:length( SM.f ), ...
    'FontSize', 13, 'FontName', 'Courier', 'FontWeight', 'Bold', 'XTickLabel', ' ' );
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%