g = tf( 7, [1 9 20] )
pole( g ) 
step( g )

h = zpk( [], [-5 -4], 7 )
step( h )
