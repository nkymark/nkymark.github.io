function [sys,x0,str,ts,simStateCompliance] = pendan(t,x,u,flag,RefBlock)
%PENDAN S-function for making pendulum animation.
%
%   See also: PENDDEMO.

%   Copyright 1990-2014 The MathWorks, Inc.

% Plots every major integration step, but has no states of its own
switch flag,

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes(RefBlock);

  %%%%%%%%%%
  % Update %
  %%%%%%%%%%
  case 2,
    sys=mdlUpdate(t,x,u);

  %%%%%%%%%%%%%
  % Terminate %
  %%%%%%%%%%%%%
  case 9,
    sys=mdlTerminate();
    
  %%%%%%%%%%%%%%%%
  % Unused flags %
  %%%%%%%%%%%%%%%%
  case { 1, 3, 4, 9 },
    sys = [];
    
  %%%%%%%%%%%%%%%
  % DeleteBlock %
  %%%%%%%%%%%%%%%
  case 'DeleteBlock',
    LocalDeleteBlock
    
  %%%%%%%%%%%%%%%
  % DeleteFigure %
  %%%%%%%%%%%%%%%
  case 'DeleteFigure',
    LocalDeleteFigure
  
  %%%%%%%%%
  % Close %
  %%%%%%%%%
  case 'Close',
    LocalClose
   
  %%%%%%%%%%%%%%%%%%%%
  % Unexpected flags %
  %%%%%%%%%%%%%%%%%%%%
  otherwise
    error(message('simdemos:general:UnhandledFlag', num2str( flag )));
end

% end pendan

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes(RefBlock)

%
% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.
%
sizes = simsizes;

sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 0;
sizes.NumInputs      = 5;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);

%
% initialize the initial conditions
%
x0  = [];

%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times, for the pendulum example,
% the animation is updated every 0.1 seconds
%
ts  = [0.1 0];

%
% create the figure, if necessary
%
LocalPendInit(RefBlock);

% specify that the simState for this s-function is same as the default
simStateCompliance = 'DefaultSimState';

% end mdlInitializeSizes

%
%=============================================================================
% mdlUpdate
% Update the pendulum animation.
%=============================================================================
%
function sys=mdlUpdate(t,x,u) %#ok<INUSL>

fig = get_param(gcbh,'UserData');
if ishghandle(fig, 'figure'),
  if strcmp(get(fig,'Visible'),'on'),
    ud = get(fig,'UserData');
    LocalPendSets(t,ud,u);
  end
end;
 
sys = [];

% end mdlUpdate

%
%=============================================================================
% mdlTerminate
% Re-enable playback buttong for the pendulum animation.
%=============================================================================
%
function sys=mdlTerminate() 

fig = get_param(gcbh,'UserData');
if ishghandle(fig, 'figure'),
    pushButtonPlayback = findobj(fig,'Tag','penddemoPushButton');
    set(pushButtonPlayback,'Enable','on');
end;
 
sys = [];

% end mdlTerminate

%
%=============================================================================
% LocalDeleteBlock
% The animation block is being deleted, delete the associated figure.
%=============================================================================
%
function LocalDeleteBlock

fig = get_param(gcbh,'UserData');
if ishghandle(fig, 'figure'),
  delete(fig);
  set_param(gcbh,'UserData',-1)
end

% end LocalDeleteBlock

%
%=============================================================================
% LocalDeleteFigure
% The animation figure is being deleted, set the S-function UserData to -1.
%=============================================================================
%
function LocalDeleteFigure

ud = get(gcbf,'UserData');
set_param(ud.Block,'UserData',-1);
  
% end LocalDeleteFigure

%
%=============================================================================
% LocalClose
% The callback function for the animation window close button.  Delete
% the animation figure window.
%=============================================================================
%
function LocalClose

delete(gcbf)

% end LocalClose

%
%=============================================================================
% LocalPendSets
% Local function to set the position of the graphics objects in the
% inverted pendulum animation window.
%=============================================================================
%
function LocalPendSets(time,ud,u)

XDelta   = 0.4;     % cart width   
PDelta   = 0.06;     % pendulum 2 width
PDelta2  = 0.035;    % pendulum 2 width
XPendTop = u(1) + 8/5*sin(u(3));  % pendulum 1 top x pos
YPendTop = 8*cos(u(3));             % pendulum 1 top y pos
XPend2Top= XPendTop + 4/5*sin(u(4));
if ((abs(u(4)) < 0.5) && (abs(u(3)) > 0.5*pi)) || ((abs(u(4)) > 0.5) && (abs(u(3)) > 0.5*pi))
    YPend2Top= YPendTop - 4*cos(u(4));
else
    YPend2Top= YPendTop + 4*cos(u(4));
end
PDcosT   = PDelta*cos(u(3));
PDsinT   = -PDelta*sin(u(3));
PD2cosT  = PDelta2*cos(u(4));
PD2sinT  = -PDelta2*sin(u(4));
set(ud.Cart,...
  'XData',ones(2,1)*[u(1)-XDelta u(1)+XDelta]);
set(ud.Pend,...
  'XData',[XPendTop-PDcosT XPendTop+PDcosT; u(1)-PDcosT u(1)+PDcosT], ...
  'YData',[YPendTop-PDsinT YPendTop+PDsinT; -PDsinT PDsinT]);
set(ud.Pend2,...
  'XData',[XPend2Top-PD2cosT XPend2Top+PD2cosT; XPendTop-PD2cosT XPendTop+PD2cosT], ...
  'YData',[YPend2Top-PD2sinT YPend2Top+PD2sinT; YPendTop-PD2sinT YPendTop+PD2sinT]);
set(ud.TimeField,...
  'String',num2str(time));
set(ud.RefField,...
  'String',num2str(u(5),'%.2f'));
set(ud.RefMark,...
  'XData',u(5)+[-XDelta 0 XDelta]);
set(ud.CartPos,...
  'String',num2str(u(1),'%.2f'));

% Force plot to be drawn
pause(0)
drawnow

% end LocalPendSets

%
%=============================================================================
% LocalPendInit
% Local function to initialize the pendulum animation.  If the animation
% window already exists, it is brought to the front.  Otherwise, a new
% figure window is created.
%=============================================================================
%
function LocalPendInit(RefBlock)

%
% The name of the reference is derived from the name of the
% subsystem block that owns the pendulum animation S-function block.
% This subsystem is the current system and is assumed to be the same
% layer at which the reference block resides.
%
sys = get_param(gcs,'Parent');

Cart      = 0;
RefCart   = 0;
TimeClock = 0;
RefSignal = str2double(get_param([sys '/' RefBlock],'Value'));
XCart     = 0;
Theta     = 0;
Theta2    = 0;

XDelta    = 0.4;
PDelta    = 0.06;
PDelta2   = 0.035;
XPendTop  = XCart + 8/5*sin(Theta);   % Will be zero
YPendTop  = 8*cos(Theta);               % Will be 10
XPend2Top = XPendTop + 4/5*sin(Theta2);
if (abs(Theta2) > 0.5)
    YPend2Top= (YPendTop - 4*cos(Theta2))/5;
else
    YPend2Top= (YPendTop + 4*cos(Theta2))/5;
end
PDcosT    = PDelta*cos(Theta);     % Will be 0.2
PDsinT    = -PDelta*sin(Theta);    % Will be zero
PD2cosT   = PDelta2*cos(Theta2);
PD2sinT   = -PDelta2*sin(Theta2);

%
% The animation figure handle is stored in the pendulum block's UserData.
% If it exists, initialize the reference mark, time, cart, and pendulum
% positions/strings/etc.
%
Fig = get_param(gcbh,'UserData');
if ishghandle(Fig ,'figure'),
  FigUD = get(Fig,'UserData');
  set(FigUD.RefMark,...
      'XData',RefSignal+[-XDelta 0 XDelta]);
  set(FigUD.TimeField,...
      'String',num2str(TimeClock));
  set(FigUD.Cart,...
      'XData',ones(2,1)*[XCart-XDelta XCart+XDelta]);
  set(FigUD.Pend,...
      'XData',[XPendTop-PDcosT XPendTop+PDcosT; XCart-PDcosT XCart+PDcosT],...
      'YData',[YPendTop-PDsinT YPendTop+PDsinT; -PDsinT PDsinT]);
  set(FigUD.Pend2,...
      'XData',[XPend2Top-PD2cosT XPend2Top+PD2cosT; XPendTop-PD2cosT XPendTop+PD2cosT],...
      'YData',[YPend2Top-PD2sinT YPend2Top+PD2sinT; -PD2sinT PD2sinT]);
  set(FigUD.RefField,...
      'String',num2str(RefCart));
  
  % disable playback button during simulation
  pushButtonPlayback = findobj(Fig,'Tag','penddemoPushButton');
  set(pushButtonPlayback,'Enable','off');
        
  %
  % bring it to the front
  %
  figure(Fig);
  return
end

%
% the animation figure doesn't exist, create a new one and store its
% handle in the animation block's UserData
%
FigureName = 'Pendulum Visualization';
Fig = figure(...
  'Units',           'pixel',...
  'Position',        [300 100 700 650],...
  'Name',            FigureName,...
  'NumberTitle',     'off',...
  'IntegerHandle',   'off',...
  'HandleVisibility','callback',...
  'Resize',          'off',...
  'DeleteFcn',       'pendan([],[],[],''DeleteFigure'')',...
  'CloseRequestFcn', 'pendan([],[],[],''Close'');');
AxesH = axes(...
  'Parent',  Fig,...
  'Units',   'pixel',...
  'Position',[50 50 600 500],...
  'CLim',    [1 64], ...
  'Xlim',    [-3 3],...
  'Ylim',    [-13 13],...
  'Visible', 'off');
Cart = surface(...
  'Parent',   AxesH,...
  'XData',    ones(2,1)*[XCart-XDelta XCart+XDelta],...
  'YData',    [0 0; -2 -2],...
  'ZData',    zeros(2),...
  'CData',    ones(2));
Pend = surface(...
  'Parent',   AxesH,...
  'XData',    [XPendTop-PDcosT XPendTop+PDcosT; XCart-PDcosT XCart+PDcosT],...
  'YData',    [YPendTop-PDsinT YPendTop+PDsinT; -PDsinT PDsinT],...
  'ZData',    zeros(2),...
  'CData',    11*ones(2));
Pend2 = surface(...
  'Parent',   AxesH,...
  'XData',    [XPend2Top-PD2cosT XPend2Top+PD2cosT; XPendTop-PD2cosT XPendTop+PD2cosT],...
  'YData',    [YPend2Top-PD2sinT YPend2Top+PD2sinT; -PD2sinT PD2sinT],...
  'ZData',    zeros(2),...
  'CData',    11*ones(2));
RefMark = patch(...
  'Parent',   AxesH,...
  'XData',    [-XDelta 0 XDelta],...
  'YData',    [-2 0 -2],...
  'CData',    22,...
  'FaceColor','flat');
uicontrol(...
  'Parent',  Fig,...
  'Style',   'text',...
  'Units',   'pixel',...
  'Position',[0 0 700 70]);
uicontrol(...
  'Parent',             Fig,...
  'Style',              'text',...
  'Units',              'pixel',...
  'Position',           [350 50 100 25], ...
  'HorizontalAlignment','right',...
  'String',             'Time : ');
uicontrol(...
  'Parent',             Fig,...
  'Style',              'text',...
  'Units',              'pixel',...
  'Position',           [100 50 150 25], ...
  'HorizontalAlignment','left',...
  'String',             'Cart Ref Position    : ');
uicontrol(...
  'Parent',             Fig,...
  'Style',              'text',...
  'Units',              'pixel',...
  'Position',           [100 10 200 25], ...
  'HorizontalAlignment','left',...
  'String',             'Cart Actual Position : ');
TimeField = uicontrol(...
  'Parent',             Fig,...
  'Style',              'text',...
  'Units',              'pixel', ...
  'Position',           [470 50 35 25],...
  'HorizontalAlignment','right',...
  'String',             num2str(TimeClock));
CartPos = uicontrol(...
  'Parent',             Fig,...
  'Style',              'text',...
  'Units',              'pixel', ...
  'Position',           [250 10 50 25],...
  'HorizontalAlignment','right',...
  'String',             num2str(TimeClock));
RefField = uicontrol(...
  'Parent',             Fig,...
  'Style',              'text',...
  'Units',              'pixel', ...
  'Position',           [250 50 50 25],...
  'HorizontalAlignment','right',...
  'String',             num2str(TimeClock));
uicontrol(...
  'Parent',             Fig,...
  'Style',              'text',...
  'Units',              'pixel', ...
  'Position',           [515 50 100 25],...
  'HorizontalAlignment','left',...
  'String',             's');
uicontrol(...
  'Parent',             Fig,...
  'Style',              'text',...
  'Units',              'pixel', ...
  'Position',           [310 10 15 25],...
  'HorizontalAlignment','left',...
  'String',             'm');
uicontrol(...
  'Parent',             Fig,...
  'Style',              'text',...
  'Units',              'pixel', ...
  'Position',           [310 50 15 25],...
  'HorizontalAlignment','left',...
  'String',             'm');
uicontrol(...
  'Parent',  Fig,...
  'Style',   'pushbutton',...
  'Position',[600 50 70 30],...
  'String',  'Close', ...
  'Callback','pendan([],[],[],''Close'');');

%
% all the HG objects are created, store them into the Figure's UserData
%
FigUD.Cart         = Cart;
FigUD.CartPos      = CartPos;
FigUD.Pend         = Pend;
FigUD.Pend2        = Pend2;
FigUD.TimeField    = TimeField;
FigUD.RefField     = RefField;
FigUD.RefMark      = RefMark;
FigUD.Block        = get_param(gcbh,'Handle');
FigUD.RefBlock     = get_param( [sys '/' RefBlock],'Handle');
set(Fig,'UserData',FigUD);

drawnow

%
% store the figure handle in the animation block's UserData
%
set_param(gcbh,'UserData',Fig);

% end LocalPendInit
