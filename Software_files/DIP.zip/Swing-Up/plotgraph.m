close
subplot(2,2,1), plot(t,ref,'r--')
hold
for i=1:1:4
if i==1
    subplot(2,2,i), plot(t,y(:,i))
    ylabel('xc and xc-ref(dashed) (m)');
elseif i==2
    subplot(2,2,i), plot(t,y(:,i))
    ylabel('xc-dot (m/s)');
elseif i==3
    subplot(2,2,i), plot(t,y(:,i)/pi*180)
    ylabel('theta-1 (deg)');
    xlabel('seconds');
else
    subplot(2,2,i), plot(t,y(:,i)/pi*180)
    ylabel('theta-2 (deg)');
    xlabel('seconds');
end

end
hold