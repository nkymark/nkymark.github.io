close

st = uicontrol('Style', 'text', 'String', 'Observer and Controller Boundaries Values', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [0 310 550 100], 'FontSize', 11, 'FontWeight', 'Bold', 'HorizontalAlignment', 'center');

st = uicontrol('Style', 'text', 'String', 'Controller Boundaries: ', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [20 270 550 100], 'FontSize', 10, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
st = uicontrol('Style', 'text', 'String', 'Upper Boundary: ', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [50 240 550 100], 'FontSize', 10, 'FontWeight', 'Demi', 'HorizontalAlignment', 'left');
st = uicontrol('Style', 'text', 'String', 'Lower Boundary: ', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [50 210 550 100], 'FontSize', 10, 'FontWeight', 'Demi', 'HorizontalAlignment', 'left');
st = uicontrol('Style', 'text', 'String', 'Half-Angle Boundary (deg): ', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [50 180 550 100], 'FontSize', 10, 'FontWeight', 'Demi', 'HorizontalAlignment', 'left');

exist ac;
 if ans==1 & ac<0
    st = uicontrol('Style', 'text', 'String', ac, 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 240 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left');
 elseif ans==1 & ac>0
    st = uicontrol('Style', 'text', 'String', 'Warning!! Boundary is positive', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 240 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left');
 else
    st = uicontrol('Style', 'text', 'String', 'Not Set', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 240 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left');
 end
 
exist bc;
 if ans==1 & bc<0
    st = uicontrol('Style', 'text', 'String', bc, 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 210 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left');    
 elseif ans==1 & bc>0
    st = uicontrol('Style', 'text', 'String', 'Warning!! Boundary is positive', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 210 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left');     
 else
    st = uicontrol('Style', 'text', 'String', 'Not Set', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 210 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left');
 end
 
 exist thetac;
 if ans==1 & thetac>0
    st = uicontrol('Style', 'text', 'String', thetac/pi*180, 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 180 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left'); 
 else
    st = uicontrol('Style', 'text', 'String', 'Not Set', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 180 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left');
 end
 
 
st = uicontrol('Style', 'text', 'String', 'Observer Boundaries: ', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [20 150 550 100], 'FontSize', 10, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
st = uicontrol('Style', 'text', 'String', 'Upper Boundary: ', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [50 120 550 100], 'FontSize', 10, 'FontWeight', 'Demi', 'HorizontalAlignment', 'left');
st = uicontrol('Style', 'text', 'String', 'Lower Boundary: ', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [50 90 550 100], 'FontSize', 10, 'FontWeight', 'Demi', 'HorizontalAlignment', 'left');
st = uicontrol('Style', 'text', 'String', 'Half-Angle Boundary (deg): ', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [50 60 550 100], 'FontSize', 10, 'FontWeight', 'Demi', 'HorizontalAlignment', 'left');

exist ao;
 if ans==1 & ao<0
    st = uicontrol('Style', 'text', 'String', ao, 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 120 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left');
 elseif ans==1 & ao>0
    st = uicontrol('Style', 'text', 'String', 'Warning!! Boundary is positive', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 120 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left'); 
 else
    st = uicontrol('Style', 'text', 'String', 'Not Set', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 120 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left');
 end
 
exist bo;
 if ans==1 & bo<0
    st = uicontrol('Style', 'text', 'String', bo, 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 90 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left');    
 elseif ans==1 & bo>0
    st = uicontrol('Style', 'text', 'String', 'Warning!! Boundary is positive', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 90 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left');     
 else
    st = uicontrol('Style', 'text', 'String', 'Not Set', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 90 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left'); 
 end
 
 exist thetao;
 if ans==1 & thetao>0
    st = uicontrol('Style', 'text', 'String', thetao/pi*180, 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 60 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left');    
 else
    st = uicontrol('Style', 'text', 'String', 'Not Set', 'BackgroundColor', [0.8,0.8,0.8], 'Position', [220 60 550 100], 'FontSize', 10, 'FontWeight', 'demi', 'HorizontalAlignment', 'left'); 
 end