lmisys=getlmis;

n=decnbr(lmisys);
c=zeros(n,1);

for j=1:n
   [gammaj]=defcx(lmisys,j,gamma);      % to minimize gamma
   c(j)=trace(gammaj); 
end

options=[0,500,0,0,0];
[copt,xopt]=mincx(lmisys,c,options,[],1e-10);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%													%
%	Optimisation routine ends						%
%													%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Po=dec2mat(lmisys,xopt,po);       % find back all values of variables - qc, gamma.....
Qc=dec2mat(lmisys,xopt,qc);
Yo=dec2mat(lmisys,xopt,yo);
Yc=dec2mat(lmisys,xopt,yc);
Gamma=dec2mat(lmisys,xopt,gamma); 

% L1=inv(Po)*Yo;
K1=Yc*inv(Qc);

% disp('The observer poles are at :'); disp(eig(A1-L1*C1));
disp('The controller poles are at :'); disp(eig(A1-B1*K1));