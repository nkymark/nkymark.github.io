clc
close all

A1 =    [0    1.0000         0         0         0         0
         0         0   -2.9152         0   -0.1160         0
         0         0         0    1.0000         0         0
         0         0   20.4826         0   -1.2989         0
         0         0         0         0         0    1.0000
         0         0  -29.4979         0  -21.3807         0];

B1=[     0
    1.2342
         0
   -1.9872
         0
    2.8536];

C1=[1 0 0 0 0 0
    0 1 0 0 0 0
    0 0 1 0 0 0
    0 0 0 0 1 0];

% E matrix
E(2,2) = 1;
E(4,4) = 1;
E(6,6) = 1;

% H matrix
% H(2,2) = 1;
H(3,3) = 1;
H(5,5) = 1;
H(6,6) = 0;

% LMI design starts here
[nn,nn] = size(A1);
[pp,nn] = size(C1);
[nn,mm] = size(B1);

setlmis([])

%lmivariable
[qc,n,sqc]=lmivar(1,[nn 1]);
[po,n,spo]=lmivar(1,[nn 1]);
[gamma,n,sgamma]=lmivar(1,[1 1]);
[yc,n,syc]=lmivar(2,[mm nn]);
[yo,n,syo]=lmivar(2,[nn pp]);
% The end of all LMI coding
   
s = 0;      % lmi no 1
s = s+1;    % increment lmi by 1

lmiterm([s 1 1 qc], A1, 1, 's');     % first column first row
lmiterm([s 1 1 yc], -B1, 1, 's');     % first row second column
lmiterm([s 1 3 0], E)   ;            % constant E, refer to handout
lmiterm([s 1 5 qc], 1, H');
lmiterm([s 1 6 0], H');
lmiterm([s 2 2 po], 1, A1, 's');
lmiterm([s 2 2 yo], -1, C1, 's');
lmiterm([s 2 4 po], 1, E);
% lmiterm([s 2 5 0], H');
lmiterm([s 3 3 gamma], 1, -eye(nn));
lmiterm([s 4 4 gamma], 1, -eye(nn));
lmiterm([s 5 5 gamma], 1, -eye(nn));
lmiterm([s 6 6 gamma], 1, -eye(nn));

s = s + 1;

lmiterm([-s 1 1 qc], 1, 1);  % for Qc > 0, -s for positive side

s = s + 1;

lmiterm([-s 1 1 po], 1, 1);  % for Po > 0, -s for positive side


cond = menu('Boundary selection menu', 'Boundary desired', 'No boundary');
if cond == 1
    run('menusel');
    run('results');
else
    run('results');
end