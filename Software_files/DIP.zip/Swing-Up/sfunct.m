function [sys,x0,str,ts] = sfuntmpl(t,x,u,flag, x10, x20, x30, x40, x50, x60)

switch flag,
    
  case 0,
    x0  = [x10 x20 x30 x40 x50 x60];
    [sys,str,ts]=mdlInitializeSizes;

  case 1,
    sys=mdlDerivatives(t,x,u);

  case 2,
    sys=mdlUpdate(t,x,u);

  case 3,
    sys=mdlOutputs(t,x,u);

  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);

  case 9,
    sys=mdlTerminate(t,x,u);

  otherwise
    error(['Unhandled flag = ',num2str(flag)]);

end


function [sys,str,ts]=mdlInitializeSizes

sizes = simsizes;

sizes.NumContStates  = 6;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 6;
sizes.NumInputs      = 1;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

str = [];

ts  = [0 0];


function sys=mdlDerivatives(t,x,u)

% parameter constants
h1 = 1.051;
h2 = 0.1436;
h3 = 0.0136;
h4 = 0.0867;
h5 = 0.0057;
h6 = 1.4086;
h7 = 0.0063;
h8 = 0.1339;
F = u;
%x = [xc xc-dot theta1 theta1-dot theta2 theta2-dot]

dx1 = x(2);

a = h5^2*(cos(x(5)))^2 - h7*h4;
b = -a;
dx2den = h1*a*b+b*((h2*h7*cos(x(3)) - h3*h5*cos(x(5))*cos(x(3)+x(5))) * (h2*cos(x(3)) + h3*cos(x(3)+x(5))))+a*((h3*cos(x(3)+x(5))) * (h2*cos(x(3)) * (h7 + h5*cos(x(5))) - h3*cos(x(3)+x(5))*(h4 + h5*cos(x(5)))));
dx2num = F*a*b+a*b*((h2*x(4)^2*sin(x(3)) + h3*(x(4)^2+x(6)^2)*sin(x(3)+x(5))))-b*((h2*cos(x(3)) + h3*cos(x(3)+x(5))) * (h5*cos(x(5))*(h8*sin(x(3)+x(5)) - h5*x(4)^2*sin(x(5))) - h7*(h5*(x(4)+x(6))^2 + h6*sin(x(3)))))-a*(h3*cos(x(3)+x(5)) * ((h4 + h5*cos(x(5))) * (h8*sin(x(3)+x(5)) - h5*x(4)^2*sin(x(5))) - (h7 + h5*cos(x(5)))*(h5*(x(4)+x(6))^2*sin(x(5)) + h6*sin(x(3)))));
dx2 = dx2num/dx2den;

dx3 = x(4);

w = (h3*h5*cos(x(5))*cos(x(3)+x(5)) - h2*h7*cos(x(3)));
g = -w;
dx4den = w*g*((h2*cos(x(3)) + h3*cos(x(3)+x(5))))+g*(h1*(h7*h4 - h5^2*(cos(x(5)))^2))+w*((h3*cos(x(3)+x(5))) * (h3*cos(x(3)+x(5))*(h4 + h5*cos(x(5))) - h2*cos(x(3))*(h5*cos(x(5)) + h7)));
dx4num = F*w*g+w*g*((h2*x(4)^2*sin(x(3)) + h3*(x(4)+x(6))^2*sin(x(3)+x(5))))-g*(h1*(h5*cos(x(5))*(h8*sin(x(3)+x(5)) - h5*x(4)^2*sin(x(5))) - h7*(h5*(x(4)+x(6))^2*sin(x(5)) + h6*sin(x(3)))))-w*(h3*cos(x(3)+x(5))*(h2*cos(x(3))*(h8*sin(x(3)+x(5)) - h5*x(4)^2*sin(x(5))) - h3*cos(x(3)+x(5))*(h6*sin(x(3)) + h5*(x(4)+x(6))^2*sin(x(5)))));
dx4 = dx4num/dx4den;

dx5 = x(6);

alpha = ((h3*cos(x(3)+x(5)))*(h4 + h5*cos(x(5))) - h2*cos(x(3))*(h7 + h5*cos(x(5))));
beta = -alpha;
dx6den = alpha*beta*h3 * cos(x(3)+x(5))+beta*(h1 * (h5^2*(cos(x(5)))^2 - h7*h4))+alpha*((h2*cos(x(3)) + h3*cos(x(3)+x(5))) * (h3*h5*cos(x(3)+x(5))*cos(x(5)) - h7*h2*cos(x(3))));
dx6num = F*alpha*beta+alpha*beta*(h2*x(4)^2*sin(x(3)) + h3*(x(4)+x(6))^2*sin(x(3)+x(5)))-beta*(h1*((h8*sin(x(3)+x(5)) - h5*x(4)^2*sin(x(5)))*(h4 + h5*cos(x(5))) - (h5*(x(4)+x(6))^2*sin(x(5)) + h6*sin(x(3)))*(h7 + h5*cos(x(5)))))-alpha*((h2*cos(x(3)) + h3*cos(x(3)+x(5)))*(h8*h2*cos(x(3))*sin(x(3)+x(5)) - h5*h2*x(4)^2*cos(x(3))*sin(x(5)) - h6*h3*cos(x(3)+x(5))*sin(x(3)) - h5*h3*(x(4)+x(6))^2*cos(x(3)+x(5))*sin(x(5))));
dx6 = dx6num/dx6den;


sys = [dx1 dx2 dx3 dx4 dx5 dx6];


function sys=mdlUpdate(t,x,u)

sys = [];


function sys=mdlOutputs(t,x,u)

sys = [x];


function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;


function sys=mdlTerminate(t,x,u)

sys = [];