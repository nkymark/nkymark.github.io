% lmi for the observer

if cond2 == 1
   
    s = s + 1;
    lmiterm([s 1 1 po], 1, A1, 's')
    lmiterm([s 1 1 yo], -1, C1, 's')
    lmiterm([s 1 1 po], -2*ao, 1)
    
elseif cond2 == 2

    s = s + 1;
    lmiterm([-s 1 1 po], 1, A1, 's')
    lmiterm([-s 1 1 yo], -1, C1, 's')
    lmiterm([-s 1 1 po], -2*bo, 1)
    
elseif cond2 == 3

    s = s + 1;
    lmiterm([s 1 1 po], sin(thetao), A1, 's')
    lmiterm([s 1 1 yo], -sin(thetao), C1, 's')

    lmiterm([s 1 2 po], -1, A1*cos(thetao))
    lmiterm([s 1 2 po], A1', cos(thetao))
    lmiterm([s 1 2 yo], 1, C1*cos(thetao))
    lmiterm([s 1 2 -yo], -C1', cos(thetao))

    lmiterm([s 2 1 po], 1, A1*cos(thetao))
    lmiterm([s 2 1 po], -A1', cos(thetao))
    lmiterm([s 2 1 yo], -1, C1*cos(thetao))
    lmiterm([s 2 1 -yo], C1', cos(thetao))

    lmiterm([s 2 2 po], sin(thetao), A1, 's')
    lmiterm([s 2 2 yo], -sin(thetao), C1, 's')
    
end

run('displayresults');