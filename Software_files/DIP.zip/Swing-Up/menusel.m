run('displayresults');

cond1 = menu('Boundary selection for:', 'Observer', 'Controller', 'Done');
if cond1 == 1
    for cond4 = 1:10
        cond2 = menu('Boundary selection for the observer poles', 'Upper bound ao', 'Lower bound bo', 'Half angle theta-o (deg)', 'Done');

        % region for eigenvalues of A-LC
        if cond2 == 1
            ao = inputdlg('Enter value for the upper bound ao for the observer: ');
            ao = str2double(ao);
            run('observer');
        elseif cond2 == 2
            bo = inputdlg('Enter value for the lower bound bo for the observer: ');
            bo = str2double(bo);
            run('observer');
        elseif cond2 == 3
            thetao = inputdlg('Enter value for the half angle theta-o for the observer(deg): ');
            thetao = str2double(thetao);
            thetao = thetao/180*pi;      
            run('observer');
        elseif cond2 == 4   
            break;
        end
    end

    run('menusel');

elseif cond1 == 2
    for cond4 = 1:10
        cond3 = menu('Boundary selection for the controller poles', 'Upper bound ac', 'Lower bound bc', 'Half angle theta-c (deg)', 'Done');

        % region for eigenvalues of A-BK
        if cond3 == 1
            ac = inputdlg('Enter value for the upper bound ac for the controller: ');
            ac = str2double(ac);
            run('controller');
        elseif cond3 == 2
            bc = inputdlg('Enter value for the lower bound bc for the controller: ');
            bc = str2double(bc);
            run('controller');
        elseif cond3 == 3
            thetac = inputdlg('Enter value for the half angle theta-c for the controller(deg): ');
            thetac = str2double(thetac);
            thetac = thetac/180*pi;
            run('controller');
        elseif cond3 == 4
            break;
        end
    end
    
    run('menusel');

elseif cond1 == 3
end
