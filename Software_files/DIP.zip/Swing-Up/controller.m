% lmi for the controller

if cond3 == 1

    s = s + 1;
    lmiterm([s 1 1 qc], A1, 1, 's')
    lmiterm([s 1 1 yc], -B1, 1, 's')
    lmiterm([s 1 1 qc], -2*ac, 1)
    
elseif cond3 == 2
    
    s = s + 1;
    lmiterm([-s 1 1 qc], A1, 1, 's')
    lmiterm([-s 1 1 yc], -B1, 1, 's')
    lmiterm([-s 1 1 qc], -2*bc, 1)

elseif cond3 == 3

    s = s + 1;
    lmiterm([s 1 1 qc], A1, sin(thetac), 's')
    lmiterm([s 1 1 yc], -B1, sin(thetac), 's')

    lmiterm([s 1 2 qc], 1, A1'*cos(thetac))
    lmiterm([s 1 2 qc], -A1, cos(thetac))
    lmiterm([s 1 2 yc], B1, cos(thetac))
    lmiterm([s 1 2 -yc], -1, B1'*cos(thetac))

    lmiterm([s 2 1 qc], -1, A1'*cos(thetac))
    lmiterm([s 2 1 qc], A1, cos(thetac))
    lmiterm([s 2 1 yc], -B1, cos(thetac))
    lmiterm([s 2 1 -yc], 1, B1'*cos(thetac))

    lmiterm([s 2 2 qc], A1, sin(thetac), 's')
    lmiterm([s 2 2 yc], -B1, sin(thetac), 's')
    
end

run('displayresults');