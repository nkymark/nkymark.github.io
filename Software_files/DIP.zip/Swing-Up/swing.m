%
%
% LMI-based Swing-up Control of A Double Inverted Pendulum
% 
% Copyright (c) 2006-2015 
%
% Author: Kok Yew Ng (Mark Ng)
%
% Date: June 2015
%
%

clear
close all
clc

cond = menu('Controller Design Setup', 'Use Pre-designed Controller', 'Design Controller Using LMI Method', 'Exit');
if cond==1
    load data;
elseif cond==2
    lmi1;
    load datanoK;
elseif cond==3
    return;
end

cond = menu('Simulation', 'Simulate', 'Exit');
if cond==1
    sim('swingup');
    plotgraph;
    return;
elseif cond==2
    return;
end
    
