clc 
clear
close all

G1 = zpk( [], [0 -0.2 -50], 10 );
figure( 'Name', 'G1' );
bode( G1 );
grid on;
title( '$G_1(s) = \frac{10}{s(s+0.2)(s+50)}$', 'interpreter', 'latex', 'FontSize', 20 )

G2 = zpk( [-4], [0 -0.2 -80], 1 );
figure( 'Name', 'G2' );
bode( G2 );
grid on;
title( '$G_2(s) = \frac{s+4}{s(s+0.2)(s+80)}$', 'interpreter', 'latex', 'FontSize', 20 )
